# ReproGrid — Design-Oriented Transient Stability Analysis of Grid-Connected Converters With Power Synchronization Control

Original paper: https://doi.org/10.1109/TIE.2018.2875669

This package runs the primary computational experiment. Use Python 3.12 from the extracted folder:

    python3.12 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    .venv/bin/python src/reproduce.py

The run writes data to results/ and figures to figures/. The included frozen protocol and source manifest describe the inputs. This is a numerical experiment; original lab validation is outside its scope.
